import React from 'react';
import { Patient } from '../types';
import { FileText, Download, FileSpreadsheet, Printer, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';

interface ReportsModuleProps {
  patients: Patient[];
}

export const ReportsModule: React.FC<ReportsModuleProps> = ({ patients }) => {
  const handleExportCSV = () => {
    const headers = ['MRN', 'Name', 'Age', 'Gender', 'Ward', 'Bed', 'SepsisRisk%', 'qSOFA', 'Lactate', 'WBC', 'HR', 'BP'];
    const rows = patients.map((p) => [
      p.mrn,
      p.name,
      p.age,
      p.gender,
      p.ward,
      p.bedNumber,
      p.currentPrediction.sepsisProbability,
      p.currentPrediction.qSofaScore,
      p.labHistory[p.labHistory.length - 1]?.lactate || 'N/A',
      p.labHistory[p.labHistory.length - 1]?.wbc || 'N/A',
      p.vitalHistory[p.vitalHistory.length - 1]?.heartRate || 'N/A',
      `${p.vitalHistory[p.vitalHistory.length - 1]?.sysBP || 'N/A'}/${p.vitalHistory[p.vitalHistory.length - 1]?.diaBP || 'N/A'}`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `SepsisSense_Clinical_Report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrintPDF = (patient: Patient) => {
    window.print();
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="glass-panel p-6 rounded-2xl border border-slate-800 bg-slate-950/80 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400">
            <FileText className="w-4 h-4" />
            <span>CLINICAL REPORT & DATA EXPORT ENGINE</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Clinical Sepsis & Audit Reports</h1>
          <p className="text-xs text-slate-400">Generate PDF SHAP Summaries • Export CSV Dataset • HL7 Compliance</p>
        </div>

        <button
          onClick={handleExportCSV}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-lg shadow-cyan-500/20 transition"
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>Export All Patients to CSV / Excel</span>
        </button>
      </div>

      {/* Patient Report Cards Generator List */}
      <div className="space-y-4">
        {patients.map((patient) => (
          <div
            key={patient.id}
            className="glass-panel p-5 rounded-2xl border border-slate-800 bg-slate-950/80 space-y-3"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-white">{patient.name} ({patient.mrn})</h3>
                <p className="text-xs text-slate-400">
                  {patient.ward} • {patient.bedNumber} • Attending: {patient.attendingPhysician}
                </p>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-xs font-mono text-cyan-400 bg-cyan-500/10 px-3 py-1 rounded-lg border border-cyan-500/30 font-bold">
                  {patient.currentPrediction.sepsisProbability}% Risk Level
                </span>

                <button
                  onClick={() => handlePrintPDF(patient)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl glass-panel text-slate-300 hover:text-white text-xs font-semibold"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print PDF Report</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs bg-slate-900/60 p-3 rounded-xl border border-slate-800">
              <div>Top Driver: <strong>{patient.currentPrediction.shapFeatures[0]?.featureName}</strong></div>
              <div>Deterioration Lead Time: <strong className="text-cyan-300">{patient.currentPrediction.deteriorationWindowHours} hrs</strong></div>
              <div>3-Hr Bundle Status: <strong className="text-emerald-400">{patient.treatmentBundleStatus.broadSpectrumAntibioticsGiven ? 'Compliant' : 'Pending'}</strong></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
