import React from 'react';
import { Patient } from '../types';
import { 
  GitCommit, 
  Calendar, 
  Stethoscope, 
  FlaskConical, 
  BrainCircuit, 
  UserCheck, 
  Syringe, 
  CheckCircle2,
  Clock,
  ChevronRight,
  AlertTriangle
} from 'lucide-react';
import { motion } from 'framer-motion';

interface PatientTimelineProps {
  patient: Patient;
  onNavigate: (module: string) => void;
}

export const PatientTimeline: React.FC<PatientTimelineProps> = ({ patient, onNavigate }) => {
  const steps = [
    {
      id: 'admission',
      title: 'Hospital Admission & Triage',
      time: patient.admissionDate,
      actor: 'ER Triage Staff',
      icon: Calendar,
      status: 'completed',
      details: `Admitted to ${patient.ward} (${patient.bedNumber}) for ${patient.primaryDiagnosis}. Primary nurse ${patient.primaryNurse} assigned.`
    },
    {
      id: 'vitals',
      title: 'Intermittent Nurse Vital Intake',
      time: patient.vitalHistory[patient.vitalHistory.length - 1]?.timestamp || 'Recent',
      actor: patient.primaryNurse,
      icon: Stethoscope,
      status: 'completed',
      details: `Latest vitals: HR ${patient.vitalHistory[patient.vitalHistory.length - 1]?.heartRate || 110} bpm, BP ${patient.vitalHistory[patient.vitalHistory.length - 1]?.sysBP || 90}/${patient.vitalHistory[patient.vitalHistory.length - 1]?.diaBP || 60} mmHg, Temp ${patient.vitalHistory[patient.vitalHistory.length - 1]?.temperature || 38.8}°C.`
    },
    {
      id: 'labs',
      title: 'Stat Laboratory Panel Processing',
      time: patient.labHistory[patient.labHistory.length - 1]?.timestamp || 'Recent',
      actor: 'Central Clinical Lab',
      icon: FlaskConical,
      status: 'completed',
      details: `Lactate ${patient.labHistory[patient.labHistory.length - 1]?.lactate || 4.2} mmol/L, WBC ${patient.labHistory[patient.labHistory.length - 1]?.wbc || 19.8}k, Procalcitonin ${patient.labHistory[patient.labHistory.length - 1]?.procalcitonin || 5.8} ng/mL.`
    },
    {
      id: 'ai_prediction',
      title: 'AI Sepsis Early-Warning Trigger',
      time: 'Predicted 4.5h window',
      actor: 'SepsisSense AI Engine',
      icon: BrainCircuit,
      status: 'active',
      details: `Sepsis Risk calculated at ${patient.currentPrediction.sepsisProbability}% (${patient.riskLevel.toUpperCase()}). SHAP identifies Serum Lactate (+32%) as top contributor.`
    },
    {
      id: 'doctor_review',
      title: 'Attending MD Intervention Approval',
      time: 'In Progress',
      actor: patient.attendingPhysician,
      icon: UserCheck,
      status: patient.treatmentBundleStatus.broadSpectrumAntibioticsGiven ? 'completed' : 'pending',
      details: 'Reviewed 3-hour Sepsis Care Bundle recommendations. Approved stat blood culture & broad-spectrum antibiotic protocol.'
    },
    {
      id: 'treatment',
      title: '3-Hour Surviving Sepsis Bundle Execution',
      time: 'Active Execution',
      actor: 'Care Team',
      icon: Syringe,
      status: patient.treatmentBundleStatus.bloodCultureDrawn && patient.treatmentBundleStatus.broadSpectrumAntibioticsGiven ? 'completed' : 'pending',
      details: `Blood Cultures: ${patient.treatmentBundleStatus.bloodCultureDrawn ? '✓ Drawn' : 'Pending'}, IV Antibiotics: ${patient.treatmentBundleStatus.broadSpectrumAntibioticsGiven ? '✓ Administered' : 'Pending'}, IV Fluids: ${patient.treatmentBundleStatus.ivFluidsAdministered ? '✓ In Progress' : 'Pending'}.`
    },
    {
      id: 'recovery',
      title: 'Hemodynamic Stabilization & Recovery',
      time: 'Expected +12h',
      actor: 'ICU / Ward Staff',
      icon: CheckCircle2,
      status: 'future',
      details: 'Continuous telemetry observation to verify lactate clearance (<2.0 mmol/L) and MAP normalization (≥65 mmHg).'
    }
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="glass-panel p-6 rounded-2xl border border-slate-800 bg-slate-950/80 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400">
            <GitCommit className="w-4 h-4" />
            <span>LONGITUDINAL CLINICAL JOURNEY TIMELINE</span>
          </div>
          <h1 className="text-2xl font-bold text-white">{patient.name} ({patient.mrn})</h1>
          <p className="text-xs text-slate-400">
            {patient.ward} • {patient.bedNumber} • Attending: {patient.attendingPhysician}
          </p>
        </div>

        <button
          onClick={() => onNavigate('prediction')}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-xs shadow-lg shadow-cyan-500/20"
        >
          <BrainCircuit className="w-4 h-4" />
          <span>View SHAP Explainable AI &rarr;</span>
        </button>
      </div>

      {/* Timeline Steps Card */}
      <div className="glass-panel p-8 rounded-2xl border border-slate-800 bg-slate-950/80 space-y-8 relative">
        {/* Vertical Connecting Line */}
        <div className="absolute left-[39px] top-12 bottom-12 w-0.5 bg-slate-800" />

        {steps.map((step, index) => {
          const Icon = step.icon;
          const isCompleted = step.status === 'completed';
          const isActive = step.status === 'active';
          const isPending = step.status === 'pending';

          return (
            <motion.div
              key={step.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="relative flex items-start gap-6 group"
            >
              {/* Step Node Icon */}
              <div
                className={`relative z-10 w-10 h-10 rounded-2xl flex items-center justify-center border transition ${
                  isCompleted
                    ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400'
                    : isActive
                    ? 'bg-cyan-500/20 border-cyan-500/60 text-cyan-300 neon-glow-cyan'
                    : isPending
                    ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                    : 'bg-slate-900 border-slate-800 text-slate-600'
                }`}
              >
                <Icon className="w-5 h-5" />
              </div>

              {/* Step Content */}
              <div className="flex-1 glass-panel p-5 rounded-2xl border border-slate-800 bg-slate-900/60 space-y-1.5 hover:border-slate-700 transition">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    {step.title}
                    {isActive && (
                      <span className="text-[10px] font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/30">
                        AI TRIGGER ACTIVE
                      </span>
                    )}
                  </h3>
                  <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-500" />
                    {step.time}
                  </span>
                </div>

                <div className="text-[11px] font-medium text-cyan-400">
                  Care Provider: {step.actor}
                </div>

                <p className="text-xs text-slate-300 leading-relaxed pt-1 border-t border-slate-800/80">
                  {step.details}
                </p>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
