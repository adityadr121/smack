import { Request, Response } from 'express';
import { logger } from '../utils/logger';

export class PatientController {
  public static async getAll(req: Request, res: Response): Promise<void> {
    logger.info('Fetching all patient EHR records');
    res.status(200).json({
      success: true,
      count: 16,
      data: [
        {
          id: 'p-101',
          mrn: 'MRN-884920',
          name: 'Eleanor Vance',
          age: 68,
          gender: 'Female',
          bloodGroup: 'A+',
          ward: 'ICU-Alpha',
          bedNumber: 'Bed A-04',
          attendingDoctor: 'Dr. Sarah Jenkins, MD',
          primaryNurse: 'RN Marcus Vance',
          riskLevel: 'critical',
          sepsisProbability: 87.4,
          status: 'Admitted'
        }
      ]
    });
  }

  public static async getById(req: Request, res: Response): Promise<void> {
    const { id } = req.params;
    logger.info(`Fetching EHR detail for patient ${id}`);
    res.status(200).json({
      success: true,
      data: {
        id,
        mrn: 'MRN-884920',
        name: 'Eleanor Vance',
        age: 68,
        gender: 'Female',
        bloodGroup: 'A+',
        ward: 'ICU-Alpha',
        bedNumber: 'Bed A-04',
        attendingDoctor: 'Dr. Sarah Jenkins, MD',
        primaryNurse: 'RN Marcus Vance',
        riskLevel: 'critical',
        sepsisProbability: 87.4,
        status: 'Admitted'
      }
    });
  }

  public static async create(req: Request, res: Response): Promise<void> {
    const patientData = req.body;
    logger.info(`Admitting new patient: ${patientData.name || 'Julian Thorne'}`);

    res.status(201).json({
      success: true,
      message: 'Inpatient admission requisition created successfully',
      data: {
        id: `p-${Date.now()}`,
        mrn: `MRN-${Math.floor(100000 + Math.random() * 900000)}`,
        ...patientData,
        status: 'Admitted'
      }
    });
  }

  public static async delete(req: Request, res: Response): Promise<void> {
    const { id } = req.params;
    logger.info(`Soft deleting patient EHR ${id}`);
    res.status(200).json({ success: true, message: `Patient EHR ${id} soft deleted` });
  }
}
